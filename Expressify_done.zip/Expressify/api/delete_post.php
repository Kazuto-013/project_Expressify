<?php
session_start();
require_once '../config/database.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$user_id = $_SESSION['user_id'];
$post_id = $_POST['post_id'] ?? null;

if (!$post_id) {
    http_response_code(400);
    echo json_encode(['error' => 'Post ID is required']);
    exit;
}

$db = new Database();
$conn = $db->getConnection();

// First check if the user owns the post
$stmt = $conn->prepare("SELECT user_id, media_id FROM posts WHERE id = ?");
$stmt->bind_param("i", $post_id);
$stmt->execute();
$result = $stmt->get_result();
$post = $result->fetch_assoc();

if (!$post) {
    http_response_code(404);
    echo json_encode(['error' => 'Post not found']);
    exit;
}

if ($post['user_id'] != $user_id) {
    http_response_code(403);
    echo json_encode(['error' => 'You do not have permission to delete this post']);
    exit;
}

// Start transaction
$conn->begin_transaction();

try {
    // Delete associated comments
    $stmt = $conn->prepare("DELETE FROM comments WHERE post_id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();

    // Delete associated likes
    $stmt = $conn->prepare("DELETE FROM likes WHERE post_id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();

    // Delete associated notifications
    $stmt = $conn->prepare("DELETE FROM notifications WHERE post_id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();

    // If there's an associated media, delete it
    if ($post['media_id']) {
        // Get media file path
        $stmt = $conn->prepare("SELECT file_path FROM media WHERE id = ?");
        $stmt->bind_param("i", $post['media_id']);
        $stmt->execute();
        $media = $stmt->get_result()->fetch_assoc();
        
        if ($media && file_exists('../' . $media['file_path'])) {
            unlink('../' . $media['file_path']);
        }

        // Delete media record
        $stmt = $conn->prepare("DELETE FROM media WHERE id = ?");
        $stmt->bind_param("i", $post['media_id']);
        $stmt->execute();
    }

    // Delete the post
    $stmt = $conn->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();

    $conn->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    $conn->rollback();
    http_response_code(500);
    echo json_encode(['error' => 'Failed to delete post']);
} 
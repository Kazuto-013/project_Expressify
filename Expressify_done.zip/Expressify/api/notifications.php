<?php
session_start();
require_once '../config/database.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$db = new Database();
$conn = $db->getConnection();
$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch notifications
    $query = "SELECT n.*, u.username, u.profile_picture,
                     p.content as post_content
              FROM notifications n 
              LEFT JOIN users u ON n.related_user_id = u.id 
              LEFT JOIN posts p ON n.post_id = p.id
              WHERE n.user_id = ? 
              ORDER BY n.created_at DESC 
              LIMIT 10";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $notifications = [];
    while ($row = $result->fetch_assoc()) {
        $notifications[] = [
            'id' => $row['id'],
            'type' => $row['type'],
            'message' => $row['message'],
            'post_content' => $row['post_content'],
            'is_read' => (bool)$row['is_read'],
            'created_at' => $row['created_at'],
            'username' => $row['username'],
            'profile_picture' => $row['profile_picture']
        ];
    }
    
    echo json_encode(['notifications' => $notifications]);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'mark_read') {
        // Mark notification as read
        $notification_id = $_POST['notification_id'] ?? null;
        
        if ($notification_id) {
            $query = "UPDATE notifications SET is_read = TRUE WHERE id = ? AND user_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ii", $notification_id, $user_id);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true]);
            } else {
                http_response_code(500);
                echo json_encode(['error' => 'Failed to mark notification as read']);
            }
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Notification ID required']);
        }
    } elseif ($_POST['action'] === 'mark_all_read') {
        // Mark all notifications as read
        $query = "UPDATE notifications SET is_read = TRUE WHERE user_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $user_id);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to mark all notifications as read']);
        }
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
} 
<?php
require 'session.php';
require 'config.php';

if (isset($_POST['like'])) {
    $post_id = $_POST['post_id'];
    $user_id = $_SESSION['user_id'];
    $stmt = $conn->prepare("INSERT INTO likes (post_id, user_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $post_id, $user_id);
    $stmt->execute();
}

if (isset($_POST['comment'])) {
    $post_id = $_POST['post_id'];
    $comment = $_POST['comment_text'];
    $user_id = $_SESSION['user_id'];
    $stmt = $conn->prepare("INSERT INTO comments (post_id, user_id, comment) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $post_id, $user_id, $comment);
    $stmt->execute();
}

header("Location: home.php");
?>

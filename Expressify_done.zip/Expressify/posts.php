<?php
require 'session.php';
require 'config.php';
require 'theme.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content = $_POST['content'];
    $user_id = $_SESSION['user_id'];
    
    try {
        $conn->begin_transaction();
        
        $media_id = null;
        // Handle media upload
        if (isset($_FILES['media']) && $_FILES['media']['error'] === 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'mp4', 'mov'];
            $filename = $_FILES['media']['name'];
            $filetype = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            $filesize = $_FILES['media']['size'];
            
            if (in_array($filetype, $allowed)) {
                $upload_path = "uploads/posts/";
                if (!file_exists($upload_path)) {
                    mkdir($upload_path, 0777, true);
                }
                
                $new_filename = uniqid() . '_' . time() . '.' . $filetype;
                $filepath = $upload_path . $new_filename;
                
                if (move_uploaded_file($_FILES['media']['tmp_name'], $filepath)) {
                    // Insert into media table
                    $stmt = $conn->prepare("INSERT INTO media (user_id, file_name, file_path, file_type, file_size) VALUES (?, ?, ?, ?, ?)");
                    $stmt->bind_param("isssi", $user_id, $new_filename, $filepath, $filetype, $filesize);
                    $stmt->execute();
                    $media_id = $conn->insert_id;
                }
            } else {
                throw new Exception("Invalid file type. Allowed types: " . implode(', ', $allowed));
            }
        }
        
        // Insert post with optional media
        $stmt = $conn->prepare("INSERT INTO posts (user_id, content, media_id) VALUES (?, ?, ?)");
        $stmt->bind_param("isi", $user_id, $content, $media_id);
        $stmt->execute();
        
        $conn->commit();
        header("Location: home.php");
        exit;
        
    } catch (Exception $e) {
        $conn->rollback();
        $message = '<div class="alert error">' . htmlspecialchars($e->getMessage()) . '</div>';
    }
}
?>
<!DOCTYPE html>
<html data-theme="<?php echo htmlspecialchars($current_theme); ?>">
<head>
    <title>Create Post - Expressify</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="container">
    <nav class="navbar">
        <div class="nav-brand">
            <h2>Expressify</h2>
        </div>
        <div class="nav-links">
            <a href="home.php" class="nav-item"><i class="fas fa-home"></i> Home</a>
            <a href="posts.php" class="nav-item active"><i class="fas fa-pen"></i> Create Post</a>
            <a href="explore.php" class="nav-item"><i class="fas fa-compass"></i> Explore</a>
            <a href="profile.php" class="nav-item"><i class="fas fa-user"></i> My Profile</a>
            <a href="friends.php" class="nav-item"><i class="fas fa-users"></i> Friends</a>
            <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
        <div class="nav-toggle">
            <i class="fas fa-bars"></i>
        </div>
    </nav>

    <div class="content">
        <h2>Create a Post</h2>
        <?php echo $message; ?>
        <form method="POST" class="post-form" enctype="multipart/form-data">
            <div class="media-preview" id="mediaPreview" style="display: none;">
                <img id="imagePreview" style="display: none;" alt="Preview">
                <video id="videoPreview" style="display: none;" controls></video>
                <button type="button" class="remove-media" onclick="removeMedia()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <textarea name="content" required placeholder="What's on your mind?" class="post-textarea"></textarea>
            <div class="post-actions">
                <div class="media-upload">
                    <label for="media" class="media-upload-btn">
                        <i class="fas fa-image"></i> Add Photo/Video
                    </label>
                    <input type="file" id="media" name="media" accept="image/*,video/*" style="display: none;">
                </div>
                <button type="submit" class="post-submit">
                    <i class="fas fa-paper-plane"></i> Post
                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.querySelector('.nav-toggle').addEventListener('click', function() {
    document.querySelector('.nav-links').classList.toggle('active');
});

// Media preview functionality
const mediaInput = document.getElementById('media');
const mediaPreview = document.getElementById('mediaPreview');
const imagePreview = document.getElementById('imagePreview');
const videoPreview = document.getElementById('videoPreview');

mediaInput.addEventListener('change', function(e) {
    if (this.files && this.files[0]) {
        const file = this.files[0];
        const reader = new FileReader();
        
        reader.onload = function(e) {
            if (file.type.startsWith('image/')) {
                imagePreview.src = e.target.result;
                imagePreview.style.display = 'block';
                videoPreview.style.display = 'none';
            } else if (file.type.startsWith('video/')) {
                videoPreview.src = e.target.result;
                videoPreview.style.display = 'block';
                imagePreview.style.display = 'none';
            }
            mediaPreview.style.display = 'block';
        }
        
        reader.readAsDataURL(file);
    }
});

function removeMedia() {
    mediaInput.value = '';
    mediaPreview.style.display = 'none';
    imagePreview.style.display = 'none';
    videoPreview.style.display = 'none';
    imagePreview.src = '';
    videoPreview.src = '';
}
</script>
</body>
</html>

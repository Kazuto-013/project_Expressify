<?php
require 'session.php';
require 'config.php';
require 'theme.php';

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $theme = $_POST['theme'];
    $stmt = $conn->prepare("UPDATE settings SET theme = ? WHERE user_id = ?");
    $stmt->bind_param("si", $theme, $user_id);
    if ($stmt->execute()) {
        $_SESSION['theme'] = $theme;
        // Return JSON response for AJAX requests
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'theme' => $theme]);
            exit;
        }
    }
}

$stmt = $conn->prepare("SELECT theme FROM settings WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$theme = $result->fetch_assoc()['theme'] ?? 'light';
$_SESSION['theme'] = $theme;
?>
<!DOCTYPE html>
<html data-theme="<?php echo htmlspecialchars($theme); ?>">
<head>
    <title>Settings - Expressify</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="container">
    <nav class="navbar">
        <div class="nav-brand">
            <h2>Expressify</h2>
        </div>
        <div class="nav-links">
            <a href="home.php" class="nav-item"><i class="fas fa-home"></i> Home</a>
            <a href="posts.php" class="nav-item"><i class="fas fa-pen"></i> Create Post</a>
            <a href="explore.php" class="nav-item"><i class="fas fa-compass"></i> Explore</a>
            <a href="profile.php" class="nav-item"><i class="fas fa-user"></i> My Profile</a>
            <a href="friends.php" class="nav-item"><i class="fas fa-users"></i> Friends</a>
            <a href="settings.php" class="nav-item active"><i class="fas fa-cog"></i> Settings</a>
            <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
        <div class="nav-toggle">
            <i class="fas fa-bars"></i>
        </div>
    </nav>

    <div class="content">
        <div class="settings-container">
            <h2>Settings</h2>
            <form method="POST" id="settingsForm" class="settings-form">
                <div class="theme-selector">
                    <h3>Theme Settings</h3>
                    <div class="theme-options">
                        <div class="theme-option">
                            <input type="radio" id="lightTheme" name="theme" value="light" 
                                   <?php echo $theme === 'light' ? 'checked' : ''; ?>>
                            <label for="lightTheme" class="theme-label light-theme">
                                <i class="fas fa-sun"></i>
                                <span>Light Theme</span>
                            </label>
                        </div>
                        <div class="theme-option">
                            <input type="radio" id="darkTheme" name="theme" value="dark"
                                   <?php echo $theme === 'dark' ? 'checked' : ''; ?>>
                            <label for="darkTheme" class="theme-label dark-theme">
                                <i class="fas fa-moon"></i>
                                <span>Dark Theme</span>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="settings-actions">
                    <button type="submit" class="save-button">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Theme preview and save functionality
document.addEventListener('DOMContentLoaded', function() {
    const themeInputs = document.querySelectorAll('input[name="theme"]');
    const form = document.getElementById('settingsForm');
    let currentTheme = '<?php echo $theme; ?>';

    // Preview theme when radio buttons are clicked
    themeInputs.forEach(input => {
        input.addEventListener('change', function() {
            document.documentElement.setAttribute('data-theme', this.value);
        });
    });

    // Handle form submission with AJAX
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = new FormData(form);
        const newTheme = formData.get('theme');

        try {
            const response = await fetch('settings.php', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });

            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    currentTheme = data.theme;
                    // Show success message
                    showNotification('Theme saved successfully!', 'success');
                }
            } else {
                throw new Error('Failed to save theme');
            }
        } catch (error) {
            console.error('Error:', error);
            showNotification('Failed to save theme settings', 'error');
        }
    });
});

// Mobile menu toggle
document.querySelector('.nav-toggle').addEventListener('click', function() {
    document.querySelector('.nav-links').classList.toggle('active');
});

// Notification system
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        ${message}
    `;
    document.body.appendChild(notification);

    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}
</script>
</body>
</html>

<?php
if (!isset($_SESSION['theme'])) {
    // Check if user has a theme set in database
    if (isset($_SESSION['user_id'])) {
        $theme_stmt = $conn->prepare("SELECT theme FROM settings WHERE user_id = ?");
        $theme_stmt->bind_param("i", $_SESSION['user_id']);
        $theme_stmt->execute();
        $theme_result = $theme_stmt->get_result();
        if ($theme_result->num_rows > 0) {
            $_SESSION['theme'] = $theme_result->fetch_assoc()['theme'];
        } else {
            // Create default theme settings for user
            $default_theme = 'light';
            $theme_stmt = $conn->prepare("INSERT INTO settings (user_id, theme) VALUES (?, ?)");
            $theme_stmt->bind_param("is", $_SESSION['user_id'], $default_theme);
            $theme_stmt->execute();
            $_SESSION['theme'] = $default_theme;
        }
    } else {
        $_SESSION['theme'] = 'light';
    }
}

$current_theme = $_SESSION['theme'] ?? 'light';
?>